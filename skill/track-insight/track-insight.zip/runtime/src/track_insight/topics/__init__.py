"""Event-to-Topic processing."""
