"""Human-readable POC reporting."""
