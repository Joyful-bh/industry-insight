"""Shared domain primitives."""
