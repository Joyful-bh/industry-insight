"""Research planning stage."""
